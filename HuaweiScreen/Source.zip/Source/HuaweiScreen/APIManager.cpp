// Fill out your copyright notice in the Description page of Project Settings.


#include "APIManager.h"

// Sets default values
AAPIManager::AAPIManager()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void AAPIManager::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AAPIManager::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

